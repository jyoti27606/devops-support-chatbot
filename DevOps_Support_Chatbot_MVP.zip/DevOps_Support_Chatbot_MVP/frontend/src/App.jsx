import { useState } from 'react';
import { Bot, Send, ShieldCheck, Terminal, ThumbsDown, ThumbsUp, Trash2, Cloud, Server, Boxes } from 'lucide-react';

const API_URL = 'http://127.0.0.1:8000';

const suggestions = [
  'Pod is in CrashLoopBackOff',
  'AccessDenied when uploading to S3',
  'Docker build fails at npm install',
  '502 Bad Gateway after deployment',
];

export default function App() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      welcome: true,
      text: "Hi! I'm your DevOps Support Assistant. Paste an error or describe what went wrong, and I'll search the knowledge base for likely causes and safe troubleshooting steps."
    }
  ]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function sendMessage(text = input) {
    const message = text.trim();
    if (!message || loading) return;
    setInput('');
    setError('');
    setMessages((old) => [...old, { role: 'user', text: message }]);
    setLoading(true);

    try {
      const response = await fetch(`${API_URL}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message }),
      });
      if (!response.ok) throw new Error(`Backend returned HTTP ${response.status}`);
      const data = await response.json();
      setMessages((old) => [...old, {
        role: 'assistant',
        text: data.answer.problem,
        answer: data.answer,
        issueId: data.issue_id || 'unknown',
      }]);
    } catch (e) {
      setError('Could not connect to the Python backend. Make sure FastAPI is running at http://127.0.0.1:8000.');
    } finally {
      setLoading(false);
    }
  }

  async function sendFeedback(issueId, helpful) {
    try {
      await fetch(`${API_URL}/api/feedback`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ issue_id: issueId, helpful }),
      });
    } catch {
      // Feedback is optional in this prototype.
    }
  }

  function clearChat() {
    setMessages([{
      role: 'assistant',
      welcome: true,
      text: "Hi! I'm your DevOps Support Assistant. Paste an error or describe what went wrong, and I'll search the knowledge base for likely causes and safe troubleshooting steps."
    }]);
    setError('');
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><div className="brand-mark"><Bot size={23} /></div><div><strong>OpsPilot</strong><span>DEVOPS SUPPORT AI</span></div></div>
        <button className="new-chat" onClick={clearChat}><span>＋</span> New conversation</button>
        <div className="side-label">SUPPORTED AREAS</div>
        <div className="nav-item"><Cloud size={17} /> AWS & permissions</div>
        <div className="nav-item"><Boxes size={17} /> Docker & containers</div>
        <div className="nav-item"><Terminal size={17} /> Kubernetes & CI/CD</div>
        <div className="nav-item"><Server size={17} /> Server errors</div>
        <div className="sidebar-bottom"><ShieldCheck size={16} /><span>Safe troubleshooting<br /><small>Suggestions only · No commands run</small></span></div>
      </aside>

      <main className="main-panel">
        <header className="topbar"><div><span className="status-dot"></span> DevOps Support <span className="beta">MVP</span></div><div className="topbar-right">Python API <span className="tiny-dot"></span> Knowledge search</div></header>
        <section className="chat-area">
          <div className="intro">
            <div className="intro-icon"><Bot size={28} /></div>
            <p className="eyebrow">YOUR DEVOPS TROUBLESHOOTING ASSISTANT</p>
            <h1>Let's solve the issue.</h1>
            <p className="intro-copy">Share an error message or log. I'll look for a known issue and guide you through the next steps.</p>
          </div>

          {messages.length === 1 && (
            <div className="suggestions">
              <p>TRY A COMMON ISSUE</p>
              <div className="suggestion-grid">
                {suggestions.map((s) => <button key={s} onClick={() => sendMessage(s)}>{s}<span>↗</span></button>)}
              </div>
            </div>
          )}

          <div className="messages">
            {messages.map((m, index) => (
              <div className={`message-row ${m.role}`} key={index}>
                {m.role === 'assistant' && <div className="avatar"><Bot size={18} /></div>}
                <div className="message-content">
                  {m.role === 'user' ? <div className="user-bubble">{m.text}</div> : (
                    <div className="assistant-card">
                      {m.welcome ? <p className="welcome-text">{m.text}</p> : <>
                        <h3>{m.answer?.problem || m.text}</h3>
                        {m.answer && <>
                          <div className="answer-section"><span className="section-number">01</span><div><strong>Likely cause</strong><p>{m.answer.likely_cause}</p></div></div>
                          <div className="answer-section"><span className="section-number">02</span><div><strong>Fix steps</strong><ol>{m.answer.fix_steps?.map((step, i) => <li key={i}>{step}</li>)}</ol></div></div>
                          <div className="answer-section"><span className="section-number">03</span><div><strong>Extra tips</strong><ul>{m.answer.extra_tips?.map((tip, i) => <li key={i}>{tip}</li>)}</ul></div></div>
                          {m.answer.official_docs && <a className="docs-link" href={m.answer.official_docs} target="_blank" rel="noreferrer">Open official documentation ↗</a>}
                          <div className="feedback"><span>Was this helpful?</span><button onClick={() => sendFeedback(m.issueId, true)} aria-label="Helpful"><ThumbsUp size={15}/></button><button onClick={() => sendFeedback(m.issueId, false)} aria-label="Not helpful"><ThumbsDown size={15}/></button></div>
                        </>}
                      </>}
                    </div>
                  )}
                </div>
              </div>
            ))}
            {loading && <div className="loading-line"><span></span><span></span><span></span> Searching knowledge base...</div>}
          </div>
          {error && <div className="error-banner">{error}</div>}
        </section>

        <div className="composer-wrap">
          <form className="composer" onSubmit={(e) => { e.preventDefault(); sendMessage(); }}>
            <textarea value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } }} placeholder="Paste an error, log, or describe the problem..." rows={2} />
            <div className="composer-footer"><span><ShieldCheck size={14}/> Don't include passwords, API keys, or customer data.</span><button type="submit" disabled={!input.trim() || loading}><Send size={16}/> Send</button></div>
          </form>
          <p className="disclaimer">OpsPilot can be wrong. Verify important changes before applying them to production.</p>
        </div>
      </main>
    </div>
  );
}

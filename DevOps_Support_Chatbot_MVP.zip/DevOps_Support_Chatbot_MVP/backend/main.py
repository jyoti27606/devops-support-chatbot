from pathlib import Path
import json
import re
from typing import Optional

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent
KB_PATH = BASE_DIR / "knowledge_base.json"

app = FastAPI(
    title="DevOps Support Chatbot API",
    description="A beginner-friendly chatbot that searches a small DevOps knowledge base.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatRequest(BaseModel):
    message: str = Field(min_length=2, max_length=10000)


class FeedbackRequest(BaseModel):
    issue_id: str
    helpful: bool


def load_knowledge_base():
    with KB_PATH.open("r", encoding="utf-8") as file:
        return json.load(file)


def tokenize(text: str) -> set[str]:
    # Simple keyword search for the first prototype; no AI key is required.
    return set(re.findall(r"[a-z0-9_./-]+", text.lower()))


def find_best_match(message: str):
    issues = load_knowledge_base()
    user_words = tokenize(message)
    best_issue = None
    best_score = 0

    for issue in issues:
        searchable = " ".join([
            issue["title"],
            issue["category"],
            " ".join(issue["keywords"]),
            " ".join(issue["example_errors"]),
        ])
        issue_words = tokenize(searchable)
        score = len(user_words & issue_words)

        # Give extra weight to an exact error phrase appearing in the message.
        for example in issue["example_errors"]:
            if example.lower() in message.lower():
                score += 5

        if score > best_score:
            best_score = score
            best_issue = issue

    # Require a small match threshold to avoid confidently returning unrelated fixes.
    if best_score < 2:
        return None
    return best_issue


@app.get("/")
def home():
    return {
        "message": "DevOps Support Chatbot API is running.",
        "docs": "/docs",
        "health": "/health",
    }


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/api/issues")
def list_issues():
    issues = load_knowledge_base()
    return {
        "count": len(issues),
        "issues": [
            {"id": item["id"], "title": item["title"], "category": item["category"]}
            for item in issues
        ],
    }


@app.post("/api/chat")
def chat(request: ChatRequest):
    message = request.message.strip()

    # Safety reminder for common secret patterns.
    secret_terms = ["aws_secret_access_key", "password=", "api_key=", "token="]
    if any(term in message.lower() for term in secret_terms):
        return {
            "matched": False,
            "answer": {
                "problem": "Your message may contain a password, token, or API key.",
                "likely_cause": "The message includes a pattern that may be a secret.",
                "fix_steps": [
                    "Remove the secret from your message before continuing.",
                    "If you already shared a real key publicly, revoke or rotate it.",
                    "Share only the error text with secret values replaced by [REDACTED].",
                ],
                "extra_tips": ["Never paste passwords, API keys, or customer data into a chatbot."],
                "source": "Project safety rule",
            },
        }

    issue = find_best_match(message)

    if not issue:
        return {
            "matched": False,
            "answer": {
                "problem": "I could not confidently match this issue to my current knowledge base.",
                "likely_cause": "The error may be missing context or not yet included in this prototype.",
                "fix_steps": [
                    "Include the exact error message and the command or deployment step that failed.",
                    "Mention the tool involved (AWS, Docker, Kubernetes, or CI/CD).",
                    "Check the official documentation for the relevant tool before running commands.",
                ],
                "extra_tips": ["This basic version uses keyword matching, so it may not understand every wording."],
                "source": "No confident knowledge-base match",
            },
        }

    return {
        "matched": True,
        "answer": {
            "problem": issue["title"],
            "likely_cause": issue["cause"],
            "fix_steps": issue["fix_steps"],
            "extra_tips": issue["extra_tips"],
            "source": issue["source"],
            "official_docs": issue.get("official_docs", ""),
        },
        "issue_id": issue["id"],
    }


_feedback = []


@app.post("/api/feedback")
def feedback(request: FeedbackRequest):
    # In this MVP, feedback is kept in memory and resets when the server restarts.
    _feedback.append({"issue_id": request.issue_id, "helpful": request.helpful})
    return {"saved": True, "message": "Thank you for your feedback."}

# OpsPilot — DevOps Support Chatbot (MVP)

A beginner-friendly prototype for Team A's AI-Powered DevOps Support Chatbot project.

## What this MVP can do

- React + Vite chat interface.
- Python FastAPI backend.
- Searches a local knowledge base with 10 starter DevOps issues.
- Returns answers in the format: Problem, Likely cause, Fix steps, Extra tips.
- Includes official documentation links for matched issues.
- Includes thumbs-up / thumbs-down feedback endpoint.
- Shows a safety reminder and a basic check for possible secrets.
- Does not execute commands.

> This is a first prototype, not the final project. The assignment requires at least 30 documented issues and a test report with at least 20 questions. Expand the knowledge base and test the answers before final submission. This MVP uses keyword matching, not an LLM or vector-based RAG yet.

## Requirements

- Python 3.10+
- Node.js 18+ (prefer a current LTS release)
- npm

## 1. Start the backend

Open a terminal in the project folder:

```bash
cd backend
python -m venv .venv
```

Activate the virtual environment:

**Windows PowerShell**
```powershell
.venv\Scripts\Activate.ps1
```

**macOS/Linux**
```bash
source .venv/bin/activate
```

Install and run:

```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

Backend URLs:
- API home: http://127.0.0.1:8000
- Health check: http://127.0.0.1:8000/health
- Interactive API docs: http://127.0.0.1:8000/docs

## 2. Start the frontend

Open a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open the local URL printed by Vite, usually http://localhost:5173.

## 3. Try these sample questions

- Pod is in CrashLoopBackOff
- ImagePullBackOff
- AccessDenied when uploading to S3
- Docker build fails at npm install
- A failed GitHub Actions log
- 502 Bad Gateway after deployment
- OOMKilled

## Project architecture

```text
User
  |
  v
React + Vite chat UI
  |
  | POST /api/chat (JSON)
  v
Python FastAPI
  |
  v
Keyword search
  |
  v
backend/knowledge_base.json
  |
  v
Structured troubleshooting answer + official docs
```

## Important safety notes

- Do not paste passwords, AWS keys, API tokens, or customer data.
- Review every suggested command before using it.
- Do not run unverified commands against production systems.
- Keep secrets in environment variables or a local `.env` file; never commit secrets to GitHub.

## Suggested next steps

1. Expand `knowledge_base.json` from 10 to at least 30 well-checked issues.
2. Prepare at least 20 test questions and record results.
3. Add follow-up questions when context is missing.
4. Add an LLM only after the knowledge search is reliable.
5. Store feedback persistently if needed.
6. Add a proper `.gitignore` and check the repository for secrets before pushing.
